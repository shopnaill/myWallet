

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
         <h2 class="text-center">Project Balance | 
             <?php
                 $total = 0;
             ?>
            <?php $__currentLoopData = $balances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php
                       $total = $total +=$balance->price;
                   ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <strong><span style="color: green"> <?php echo e($total); ?> EGP</span></strong>

         </h2>
        <div class="col-md-12">
            <div style="padding: 25px" class="card">
                <table id="table_id" class="display">
                    <thead>
                        <tr>
                            <th>Project</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                         <?php $__currentLoopData = $balances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td><?php echo e($balance->project->name); ?></td>
                            <td>
                                <form action="" method="post">
                                <input step="0.01" type="number" width="50%" name="price" class="form-control" value="<?php echo e($balance->price); ?>" id="price"> 
                                <input id="submit-input" type="submit" style="display: none" value="">   
                                 </form> EGP
                                </td>
                            <td><?php echo e($balance->date); ?></td>
                            <td>
                                <label for="submit-input" class="btn btn-success btn-sm" href="#">Save</label>    
                                <label class="btn btn-danger btn-sm" href="#">Delete</label>    
                            </td>
                          </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
<script>
    $(document).ready( function () {
       $('#table_id').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\balance\resources\views/balances/index.blade.php ENDPATH**/ ?>
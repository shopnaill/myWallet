

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
         <h2 class="text-center">All Projects</h2>
         <br>
        <div class="col-md-12">
            <a class="btn btn-primary" href="<?php echo e(route('project.create')); ?>">Create Project</a>
            <br>
            <br>
            <div style="padding: 25px" class="card">
                <table id="table_id" class="display">
                    <thead>
                        <tr>
                            <th>Project</th>
                            <th>Description</th>
                            <th>Type</th>
                            <th>Link</th>
                            <th>Client</th>
                            <th>Balance</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                         <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td><?php echo e($project->name); ?></td>
                            <td><?php echo e($project->description); ?></td>
                            <td>
                                <?php if($project->type == 1): ?>
                                 <?php echo e("Web"); ?>

                                <?php elseif($project->type == 2): ?>
                                <?php echo e("Mobile"); ?>

                                <?php else: ?> 
                                <?php echo e("Other"); ?>

                                <?php endif; ?> 
                             </td>
                            <td><a target="_blank" href="<?php echo e($project->link); ?>">Preview</a></td>
                            <td><?php echo e($project->user->name); ?></td>
                            <td>
                                <?php
                                    $total =0;
                                    $p = new \App\Models\Project();
                                 ?>
                                 <?php $__currentLoopData = $p->balance($project->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php
                                         $total = $total +=$i->price;
                                     ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <strong><span style="color: green"> <?php echo e($total); ?> EGP</span></strong>

                            </td>

                             <td>
                                <a href="<?php echo e(route('balance_create',$project->id)); ?>" class="btn btn-info">+</a>   
                                <a href="<?php echo e(route('balance.index',$project->id)); ?>" class="btn btn-primary">View</a>   
                            </td>
                          </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
<script>
    $(document).ready( function () {
       $('#table_id').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\balance\resources\views/projects/index.blade.php ENDPATH**/ ?>
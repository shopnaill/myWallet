<?php
    $header = false;
?>



<?php $__env->startSection('content'); ?>
 
<h1>dsfds</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagescripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\balance\resources\views\projects\index.blade.php ENDPATH**/ ?>
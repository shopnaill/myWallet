

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
         <h2 class="text-center">My Wallet | 

            <?php
            $total =0;
             ?>
            <?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php
             if ($w->type == null)
             {
                $total = $total +=$w->amount;
             }
             if ($w->type == 1)
             {
                $total = $total -=$w->amount;
             }
             ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <strong><span style="color: green"> <?php echo e($total); ?> EGP</span></strong>
         </h2>
         <br>
        <div class="col-md-12">
            <a href="<?php echo e(route('wallet.withdraw')); ?>" class="btn btn-danger"><i class="fa fa-minus"></i></a> <a href="<?php echo e(route('wallet.create')); ?>" class="btn btn-danger"><i class="fa fa-plus"></i></a>            <br>
            <br>
            <div style="padding: 25px" class="card">
                <table id="table_id" class="display">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Info</th>
                            <th>Amount</th>
                            <th>Type</th>
                         </tr>
                    </thead>
                    <tbody>
                         <?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td><?php echo e($w->created_at); ?></td>
                            <td><?php echo e($w->info); ?></td>
                            <td>
                                <?php if($w->type == null): ?>
                                <span style="color: green;font-weight: bold;">+<?php echo e($w->amount); ?></span>
                                <?php elseif($w->type == 1): ?>
                                 <span style="color: red;font-weight: bold;">-<?php echo e($w->amount); ?></span>
                                <?php endif; ?> 
                                </td>
                            <td>
                                <?php if($w->type == null): ?>
                                <span style="color: green;font-weight: bold;"><?php echo e("Addation"); ?></span>
                                <?php elseif($w->type == 1): ?>
                                 <span style="color: red;font-weight: bold;"><?php echo e("Withdraw"); ?></span>
                                <?php endif; ?> 
                             </td>
          
 
                          </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js"></script>
<script>
    $(document).ready( function () {
       $('#table_id').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\balance\resources\views/wallet/index.blade.php ENDPATH**/ ?>